using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fecharJogo : MonoBehaviour
{
    public void SairDoJogo()
    {
        Debug.Log("Saindo do jogo...");
        Application.Quit();
    }
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
