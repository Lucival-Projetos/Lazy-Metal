using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class IniciarJogo : MonoBehaviour
{
    

    public void Iniciar()
    {
        SceneManager.LoadScene("Fase1");
    }
    void Start()
    {
        
    }

    
    void Update()
    {
        
    }
}
