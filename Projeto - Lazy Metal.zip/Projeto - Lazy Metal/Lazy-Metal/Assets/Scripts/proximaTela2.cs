using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class proximaTela2 : MonoBehaviour
{
    public void Passartela()
    {
        SceneManager.LoadScene("fase-3");
    }
}
